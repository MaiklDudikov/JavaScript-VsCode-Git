import { ContactBook } from './modules/ContactBook.js';

const contactBook = new ContactBook();
contactBook.render();
